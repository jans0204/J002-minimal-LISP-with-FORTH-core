
#include <error.h>
#include <stdarg.h>
#include <stdio.h>

void error (int status, int errnum, const char *fmt, ...)
{
    va_list ap;

    va_start(ap, fmt);
    fprintf(stderr, fmt, ap);
    fputc('\n', stderr);
    va_end(ap);
    exit(status);
}
